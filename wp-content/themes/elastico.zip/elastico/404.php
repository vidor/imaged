<?php get_header(); ?>

	<div id="full-page">
	
			<h1 class="page-title"><?php _e('Page Not Found', 'si_theme'); ?></h1>
			<div class="sep"></div>	
		
			<div id="post-0">
				<div class="entry-content">
					<p><?php _e("Sorry, but you are looking for something that isn't here.", "si_theme"); ?></p>
				</div>			
			</div>
				
	</div>

<?php get_footer(); ?> 