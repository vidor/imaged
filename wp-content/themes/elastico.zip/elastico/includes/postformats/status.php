<div class="entry-content">								
	<?php the_content('');?>		
</div>   
					