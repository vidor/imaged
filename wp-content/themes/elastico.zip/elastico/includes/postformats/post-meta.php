<div class="entry-meta clearfix">				
				<span class="entry-date"><a href="<?php the_permalink(); ?>"><?php the_time( get_option('date_format') ); ?></a></span> 				
				<span class="meta-sep">&middot;</span>
				<span class="entry-categories"><?php the_category(', ') ?></span>
</div>
