<h1 class="entry-title"><?php the_title(); ?></h1>       
<div class="sep"></div>	
<div class="entry-content">								
	<?php the_content('');?>		
</div>   
					
	
      		
